using Bogus;
using FluentAssertions;
using InchcapeWebApi.Controllers;
using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Moq;
using System.Reflection.Metadata;

namespace InchcapeWebApi.UnitTest.ControllersTest
{
    public class VehicleFinancialRatesControllerTest
    {
        // Test setup un Xunit
        public VehicleFinancialRatesControllerTest()
        {
            stub = new List<VehicleDetail>()
            {
                new VehicleDetail()
                {
                    id = Guid.NewGuid(),
                    Model = "BMW",
                    VehicleType = "Car",
                    FinanceType = "Pension",
                    ZeroToThreeMonths = 5,
                    ThreeToSixMonths = 6,
                    SixToTwelve = 7,
                    TwelvePlus = 8
                }
            };
            var data = stub.AsQueryable();

            var mockdbContext = new Mock<ApplicationDbContext>();
            var mockSet = new Mock<DbSet<VehicleDetail>>();
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.Provider).Returns(data.Provider);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.ElementType).Returns(data.ElementType);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.Expression).Returns(data.Expression);
            mockSet.As<IQueryable<VehicleDetail>>().Setup(m => m.GetEnumerator()).Returns(() => data.GetEnumerator());
            mockdbContext.Setup(x => x.VehicleDetails).Returns(mockSet.Object);

            mockdbContext.Setup(x => x.SaveChanges()).Returns(1);

            _controller = new VehicleFinancialRatesController(mockdbContext.Object);
            
        }
        List<VehicleDetail> stub;
        VehicleFinancialRatesController _controller;


        [Fact]
        public void GetVehicleFinancialRates_Returns200Status()
        {
            var result = _controller.GetVehicleFinancialRates();
            
            // Assert
            result.GetType().Should().Be(typeof(OkObjectResult));
            (result as OkObjectResult).StatusCode.Should().Be(200);
        }


        [Fact]
        public async Task AddVehicleFinancialRates_Adds_New_VehicleDetail()
        {
            var vehicleDetail = new VehicleDetail()
            {
                id = Guid.NewGuid(),
                Model = "BMW",
                VehicleType = "Car",
                FinanceType = "Pension",
                ZeroToThreeMonths = 5,
                ThreeToSixMonths = 6,
                SixToTwelve = 7,
                TwelvePlus = 8
            };
            var result = await _controller.AddVehicleFinancialRates(vehicleDetail);

            // Assert
            result.GetType().Should().Be(typeof(OkObjectResult));
            //(result as OkObjectResult).StatusCode.Should().Be(200);

        }

        //private List<VehicleDetail> GenerateData(int count)
        //{
        //    var mockDataResult = new List<VehicleDetail>()
        //    {
        //        new VehicleDetail()
        //        {
        //            id = Guid.NewGuid(),
        //            Model = "BMW",
        //            VehicleType = "Car",
        //            FinanceType = "Pension",
        //            ZeroToThreeMonths = 5,
        //            ThreeToSixMonths = 6,
        //            SixToTwelve = 7,
        //            TwelvePlus = 8
        //        }
        //    }.AsQueryable();
            

        //}
    }
}