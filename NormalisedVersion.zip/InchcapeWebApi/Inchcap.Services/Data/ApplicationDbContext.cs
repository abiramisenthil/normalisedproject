﻿using InchcapeWebApi.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Metadata;

namespace InchcapeWebApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<VehicleDetail> VehicleDetails { get; set; }

       /* public DbContext Instance => this;

        public Task SaveChangesAsync()
        {
            throw new NotImplementedException();
        }*/
    }
}
