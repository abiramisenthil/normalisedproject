﻿using InchcapeWebApi.Models;
using InchcapeWepApi.Models;
using Microsoft.EntityFrameworkCore;

namespace InchcapeWebApi.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
        {
        }
        public ApplicationDbContext(DbContextOptions options) : base(options)
        {
        }

        //public virtual DbSet<VehicleDetail> VehicleDetails { get; set; }

        //public DbSet<CarFinance> CarFinances { get; set; }

        //public DbSet<AvailableFinance> AvailableFinances { get; set; }

        public DbSet<Make> Makes { get; set; }

        public DbSet<VehicleType> VehicleTypes { get; set; }

        public DbSet<FinanceType> FinanceTypes { get; set; }

        public DbSet<FinanceRange> FinanceRanges { get; set; }

        public DbSet<VehicleMakeType> VehicleMakeTypes { get; set; }

        public DbSet<VehicleFinance> VehicleFinance { get; set; }

        public DbSet<VehicleFinanceRange> VehicleFinanceRanges { get; set; }


        /*protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<CarFinance>(entity => {
                entity.To

            });
        }
        */
        /* public DbContext Instance => this;

         public Task SaveChangesAsync()
         {
             throw new NotImplementedException();
         }*/
    }
}
