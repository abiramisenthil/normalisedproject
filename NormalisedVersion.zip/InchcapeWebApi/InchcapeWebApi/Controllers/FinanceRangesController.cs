﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using InchcapeWebApi.Data;
using InchcapeWebApi.Models;

namespace InchcapeWepApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FinanceRangesController : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public FinanceRangesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/FinanceRanges
        [HttpGet]
        public async Task<ActionResult<IEnumerable<FinanceRange>>> GetFinanceRanges()
        {
            return await _context.FinanceRanges.ToListAsync();
        }

        // GET: api/FinanceRanges/5
        [HttpGet("{id}")]
        public async Task<ActionResult<FinanceRange>> GetFinanceRange(int id)
        {
            var financeRange = await _context.FinanceRanges.FindAsync(id);

            if (financeRange == null)
            {
                return NotFound();
            }

            return financeRange;
        }

        // PUT: api/FinanceRanges/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutFinanceRange(int id, FinanceRange financeRange)
        {
            if (id != financeRange.FinanceRangeId)
            {
                return BadRequest();
            }

            _context.Entry(financeRange).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!FinanceRangeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/FinanceRanges
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<FinanceRange>> PostFinanceRange(FinanceRange financeRange)
        {
            _context.FinanceRanges.Add(financeRange);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetFinanceRange", new { id = financeRange.FinanceRangeId }, financeRange);
        }

        // DELETE: api/FinanceRanges/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFinanceRange(int id)
        {
            var financeRange = await _context.FinanceRanges.FindAsync(id);
            if (financeRange == null)
            {
                return NotFound();
            }

            _context.FinanceRanges.Remove(financeRange);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool FinanceRangeExists(int id)
        {
            return _context.FinanceRanges.Any(e => e.FinanceRangeId == id);
        }
    }
}
