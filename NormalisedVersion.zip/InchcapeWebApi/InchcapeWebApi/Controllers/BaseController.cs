﻿using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InchcapeWepApi.Controllers
{
    public class BaseController : Controller
    {
        protected readonly ApplicationDbContext _dbContext;

        public BaseController(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        protected async Task<Make> GetVehicleMakeInfo(int Id, String Name)
        {

            var record = await _dbContext.Makes
                    .FirstOrDefaultAsync(f => (Id != null && f.MakeId == Id) || (!string.IsNullOrEmpty(Name) && f.Name == Name));
            if (record != null)
                return record;


            return null;
        }

        protected async Task<VehicleType> GetVehicleTypeInfo(int Id, String Name)
        {

            var record = await _dbContext.VehicleTypes
                    .FirstOrDefaultAsync(f => (Id != null && f.VehicleTypeId == Id) || (!string.IsNullOrEmpty(Name) && f.Name == Name));
            if (record != null)
                return record;


            return null;
        }

        protected async Task<FinanceType> GetFinanceTypeInfo(int Id, String Name)
        {

            var record = await _dbContext.FinanceTypes
                    .FirstOrDefaultAsync(f => (Id != null && f.FinanceTypeId == Id) || (!string.IsNullOrEmpty(Name) && f.Name == Name));
            if (record != null)
                return record;


            return null;
        }

        protected async Task<FinanceRange> GetFinanceRangeInfo(int Id, String Name)
        {

            var record = await _dbContext.FinanceRanges
                    .FirstOrDefaultAsync(f => (Id != null && f.FinanceRangeId == Id) || (!string.IsNullOrEmpty(Name) && f.Name == Name));
            if (record != null)
                return record;


            return null;
        }
    }
}
