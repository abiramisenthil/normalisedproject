﻿using InchcapeWebApi.Data;
using InchcapeWebApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InchcapeWepApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Admin1Controller : ControllerBase
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetMakes")]
        public async Task<ActionResult<IEnumerable<Make>>> GetMakes()
        {
            return await _context.Makes.ToListAsync();
        }

        [HttpPut("UpdateMake/{id}")]
        public async Task<IActionResult> PutMake(int id, Make make)
        {
            if (id != make.MakeId)
            {
                return BadRequest();
            }

            _context.Entry(make).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MakeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        [HttpPost("AddMake")]
        public async Task<ActionResult<Make>> AddMake(Make make)
        {
            if (!string.IsNullOrEmpty(make.Name))
            {
                _context.Makes.Add(make);
                await _context.SaveChangesAsync();

                return Ok(make);
            }

            return BadRequest();

        }

        // POST: api/FinanceTypes
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<FinanceType>> PostFinanceType(FinanceType financeType)
        {
            _context.FinanceTypes.Add(financeType);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetFinanceType", new { id = financeType.FinanceTypeId }, financeType);
        }

        // POST: api/FinanceRanges
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost("InsertFinanceRange")]
        public async Task<ActionResult<FinanceRange>> PostFinanceRange(FinanceRange financeRange)
        {
            _context.FinanceRanges.Add(financeRange);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetFinanceRange", new { id = financeRange.FinanceRangeId }, financeRange);
        }

        [HttpGet("GetAllMakes")]
        public async Task<ActionResult<IEnumerable<CarFinance>>> GetAllMakes()
        {
            return await _context.CarFinances
                .AsNoTracking()
                .Include(i => i.Make)
                .Include(i => i.VehicleType)
                .Include(i => i.FinanceType)
                .Include(i => i.FinanceRange)
                .Include(i => i.AvailableFinances).ThenInclude(i => i.CarFinance)
                .Include(i => i.AvailableFinances).ThenInclude(i => i.FiananceRangeValue)
                .ToArrayAsync();
        }

        [HttpPost("PostCarFinance")]
        public async Task<ActionResult<CarFinance>> PostCarFinance(CarFinance carFinance)
        {
            _context.CarFinances.Add(carFinance);
            await _context.SaveChangesAsync();

            var car
        }


        private bool MakeExists(int id)
        {
            return _context.Makes.Any(e => e.MakeId == id);
        }
    }
}
