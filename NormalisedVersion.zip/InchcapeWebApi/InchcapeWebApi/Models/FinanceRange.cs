﻿namespace InchcapeWebApi.Models
{
    public class FinanceRange
    {
        //public FinanceRange()
        //{
        //    CarFinances = new HashSet<CarFinance>();
        //}
        public int FinanceRangeId { get; set; }

        public string Name { get; set; }

        //public ICollection<CarFinance> CarFinances { get; set; }
    }
}
