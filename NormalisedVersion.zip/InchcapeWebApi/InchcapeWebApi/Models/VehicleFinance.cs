﻿using InchcapeWebApi.Models;

namespace InchcapeWepApi.Models
{
    public class VehicleFinance
    {
        public int Id { get; set; }
        public int VehicleMakeTypeId { get; set; }
        public int FinanceTypeId { get; set; }

        public VehicleMakeType VehicleMakeType { get; set; }

        public FinanceType FinanceType { get; set; }
    }
}
