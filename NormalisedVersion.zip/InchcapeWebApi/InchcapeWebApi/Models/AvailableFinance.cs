﻿namespace InchcapeWebApi.Models
{
    public class AvailableFinance
    {
        public int Id { get; set; }

        public int CarFinanceId { get; set; }

        public int FinanceRangeId { get; set; }

        public decimal FiananceRangeValue { get; set; }

        public CarFinance CarFinance { get; set; }

        public FinanceRange FinanceRange { get; set; }       

    }
}
