﻿namespace InchcapeWebApi.Models
{
    public class FinanceType
    {
        //public FinanceType()
        //{
        //    CarFinances = new HashSet<CarFinance>();
        //}
        public int FinanceTypeId { get; set; }

        public string Name { get; set; }

        //public ICollection<CarFinance> CarFinances { get; set; }
    }
}
