﻿namespace InchcapeWebApi.Models
{
    public class Make
    {
        //public Make()
        //{
        //    CarFinances = new HashSet<CarFinance>();
        //}
        public int MakeId { get; set; }
        public string Name { get; set; }

        // public ICollection<CarFinance> CarFinances { get; set; }
    }
}
