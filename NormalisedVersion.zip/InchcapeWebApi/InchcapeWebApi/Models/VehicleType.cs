﻿namespace InchcapeWebApi.Models
{
    public class VehicleType
    {
        //public VehicleType()
        //{
        //    CarFinances = new HashSet<CarFinance>();
        //}
        public int VehicleTypeId { get; set; }

        public string Name { get; set; }

        //public ICollection<CarFinance> CarFinances { get; set; }
    }
}
