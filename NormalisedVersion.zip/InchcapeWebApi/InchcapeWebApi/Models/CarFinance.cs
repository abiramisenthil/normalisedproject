﻿namespace InchcapeWebApi.Models
{
    public class CarFinance
    {
        public CarFinance()
        {
            AvailableFinances = new HashSet<AvailableFinance>();
        }

        public int Id { get; set; }

        public int? MakeId { get; set; }

        public Make Make { get; set; }

        public int? VehicleTypeId { get; set; }

        public VehicleType VehicleType { get; set; }

       public int? FinanceTypeId { get; set; }

       public FinanceType FinanceType { get; set; }

       public int? FinanceRange { get; set; }

       public FinanceRange FinanceRanges { get; set; }

       public ICollection<AvailableFinance> AvailableFinances { get; set; }
    }
}
