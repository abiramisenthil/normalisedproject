﻿namespace InchcapeWepApi.Models
{
    public class VehicleFinanceRange
    {
        public int id { get; set; }

        public int VehicleFinanceId { get; set; }

        public int FinanceRanges { get; set; }

        public decimal values { get; set; }
    }
}
