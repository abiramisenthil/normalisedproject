﻿using System.ComponentModel.DataAnnotations;

namespace InchcapeWebApi.Models
{
    public class VehicleDetail
    {
        [Key]
        public Guid id { get; set; }

        public string Model { get; set; }

        public string VehicleType { get; set; }

        public string FinanceType { get; set; }

        public decimal ZeroToThreeMonths { get; set; }

        public decimal ThreeToSixMonths { get; set; }

        public decimal SixToTwelve { get; set; }

        public decimal TwelvePlus { get; set; }
    }
}
