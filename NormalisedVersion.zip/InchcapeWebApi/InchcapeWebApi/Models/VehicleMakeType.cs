﻿using InchcapeWebApi.Models;

namespace InchcapeWepApi.Models
{
    public class VehicleMakeType
    {
        public int Id { get; set; }
        public int MakeId { get; set; }
        public int  VehicleTypeId{ get; set; }

        public Make Make { get; set; }

        public VehicleType vehicleType { get; set; }

    }
}
